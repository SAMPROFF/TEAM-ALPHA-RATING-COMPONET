# team-Alpha-rating-component
the repo is a teamwork from team alpha (Fred, Patrick, Samuel, Justin and Clementina) working on interactive rating component
